PRIMECARE DASHBOARDS · HTML5 OFFLINE SIMULATOR

Extract the entire ZIP into a folder. Then open index.html in a browser.
Internet, server, sign-in, and installation are not needed. Enable JavaScript
for task practice and searchable index. See roles.html for the owner-role scorecard.
Dashboard identity and section information
remain readable with JavaScript off. Use fictional data only; never enter patient,
client or staff information. Use export to keep a copy of local practice data,
since access to browser storage for files and private windows can vary.

Source commit: c6772fc0a4b3500b4c5159ef777c9fd589dcc616
Registry: cloudflare/workers/src/workspace-registry.json
Exact filter: screens with renderer equal to dashboard.
Coverage: 115 unique screen IDs, names as registered, codes and routes;
584 registered sections in registry order. 336 fictional task templates. Code classifications
are based on the committed shared Dart wrapper test fixture (113)
and documented preserved specialized implementations (2).

This is an offline practice simulator, not a production UI or deployment.
Labels such as Quick Actions are catalog names. Task practice and sample records
are fictional; there are no live API requests, actual workflow execution, permission
changes, or access to PrimeCare. The manifest separates exact registry metadata
from practice scenario counts. A role name identifies a dashboard's catalog owner,
not proof that a person can access it.

Prior app checks (separate from this bundle):
https://github.com/shaikhrais/primecare-platform/actions/runs/44093113563
The app's isolated acceptance run covered 113 shared screens at two widths.
Care Delivery had dedicated route-handoff checks and Growth a separate
loading/error/retry check. These are not end-to-end workflow readiness results.
