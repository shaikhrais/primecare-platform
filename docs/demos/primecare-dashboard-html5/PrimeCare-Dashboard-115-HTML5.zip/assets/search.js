
'use strict';
const query = document.querySelector('#search');
const app = document.querySelector('#app');
const cards = Array.from(document.querySelectorAll('#entries > li'));
const count = document.querySelector('#matches');
const empty = document.querySelector('#empty');
function update() {
  const terms = query.value.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
  let visible = 0;
  for (const card of cards) {
    const hay = card.dataset.text.toLocaleLowerCase();
    const match = (!app.value || card.dataset.app === app.value) && terms.every(term => hay.includes(term));
    card.hidden = !match;
    if (match) visible += 1;
  }
  count.textContent = visible + ' of ' + cards.length + ' dashboards';
  empty.hidden = visible !== 0;
}
query.addEventListener('input',update);
app.addEventListener('change',update);
update();
